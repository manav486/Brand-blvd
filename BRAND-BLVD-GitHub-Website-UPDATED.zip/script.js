const products=[
{id:1,name:"BLVD Essential Tee",cat:"tshirts",category:"T-Shirts",price:1299,desc:"A clean everyday essential with the signature BRAND BLVD attitude.",badge:"BESTSELLER"},
{id:2,name:"Oversized Studio Tee",cat:"tshirts",category:"T-Shirts",price:1499,desc:"Relaxed oversized silhouette made for modern street styling.",badge:"NEW"},
{id:3,name:"Signature Oxford",cat:"shirts",category:"Shirts",price:1899,desc:"A versatile structured shirt for a sharper everyday look.",badge:"NEW"},
{id:4,name:"BLVD Relaxed Shirt",cat:"shirts",category:"Shirts",price:1799,desc:"Easy relaxed fit designed to layer or wear solo.",badge:""},
{id:5,name:"Straight Cut Denim",cat:"jeans",category:"Jeans",price:2299,desc:"Classic straight-leg denim with an easy, clean profile.",badge:"BESTSELLER"},
{id:6,name:"BLVD Cargo Denim",cat:"jeans",category:"Jeans",price:2499,desc:"Utility-inspired denim with a contemporary silhouette.",badge:"NEW"},
{id:7,name:"Heavyweight Hoodie",cat:"hoodies",category:"Hoodies",price:2199,desc:"Premium-looking heavyweight layer for cooler evenings.",badge:"NEW"},
{id:8,name:"BLVD Zip Hoodie",cat:"hoodies",category:"Hoodies",price:2399,desc:"A versatile zip layer with a clean minimal finish.",badge:""},
{id:9,name:"Varsity Jacket",cat:"jackets",category:"Jackets",price:3299,desc:"Statement outerwear built around a timeless varsity shape.",badge:"LIMITED"},
{id:10,name:"BLVD Coach Jacket",cat:"jackets",category:"Jackets",price:2899,desc:"Lightweight statement layer for effortless streetwear.",badge:"NEW"}
];
let cart=JSON.parse(localStorage.getItem("brandblvd-cart")||"[]");
let selectedProduct=null;

const money=n=>"₹"+n.toLocaleString("en-IN");
const grid=document.getElementById("productGrid");
const count=document.getElementById("cartCount");

function renderProducts(filter="all"){
  const list=filter==="all"?products:products.filter(p=>p.cat===filter);
  grid.innerHTML=list.map(p=>`
    <article class="product" data-id="${p.id}">
      <div class="product-img">
        ${p.badge?`<span class="badge">${p.badge}</span>`:""}
        <div class="art"></div>
        <div class="quick">VIEW PRODUCT +</div>
      </div>
      <div class="product-meta">
        <div><h3>${p.name}</h3><p>${p.category}</p></div>
        <span class="price">${money(p.price)}</span>
      </div>
    </article>`).join("");
  grid.querySelectorAll(".product").forEach(el=>el.addEventListener("click",()=>openProduct(+el.dataset.id)));
}

function save(){localStorage.setItem("brandblvd-cart",JSON.stringify(cart));renderCart();updateCount()}
function updateCount(){count.textContent=cart.reduce((a,i)=>a+i.qty,0)}
function addToCart(id,size="L"){
  const p=products.find(x=>x.id===id);
  const existing=cart.find(x=>x.id===id&&x.size===size);
  if(existing) existing.qty++; else cart.push({id,size,qty:1});
  save();toast("Added to bag");closeProduct();openCart();
}
function renderCart(){
  const box=document.getElementById("cartItems");
  if(!cart.length){box.innerHTML='<div class="empty"><h3>Your bag is empty.</h3><p>Add something you love from the collection.</p></div>';document.getElementById("cartTotal").textContent="₹0";return}
  let total=0;
  box.innerHTML=cart.map((item,index)=>{
    const p=products.find(x=>x.id===item.id); total+=p.price*item.qty;
    return `<div class="cart-item">
      <div class="cart-thumb">BB</div>
      <div><h4>${p.name}</h4><p>Size: ${item.size} • ${money(p.price)}</p>
      <div class="qty"><button onclick="changeQty(${index},-1)">−</button><b>${item.qty}</b><button onclick="changeQty(${index},1)">+</button></div></div>
      <button class="remove" onclick="removeItem(${index})">Remove</button>
    </div>`
  }).join("");
  document.getElementById("cartTotal").textContent=money(total);
}
function changeQty(i,n){cart[i].qty+=n;if(cart[i].qty<=0)cart.splice(i,1);save()}
function removeItem(i){cart.splice(i,1);save();toast("Removed from bag")}
function openCart(){document.getElementById("cart").classList.add("open");document.getElementById("overlay").classList.add("show")}
function closeCart(){document.getElementById("cart").classList.remove("open");document.getElementById("overlay").classList.remove("show")}
function openProduct(id){
  selectedProduct=products.find(p=>p.id===id);
  document.getElementById("modalCategory").textContent=selectedProduct.category;
  document.getElementById("modalName").textContent=selectedProduct.name;
  document.getElementById("modalPrice").textContent=money(selectedProduct.price);
  document.getElementById("modalDesc").textContent=selectedProduct.desc;
  document.getElementById("modalImage").innerHTML='<div class="art"></div>';
  document.getElementById("productModal").classList.add("show");
}
function closeProduct(){document.getElementById("productModal").classList.remove("show")}
function toast(text){const t=document.getElementById("toast");t.textContent=text;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}

document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.filter)
}));
document.getElementById("openCart").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
document.getElementById("overlay").onclick=closeCart;
document.getElementById("closeModal").onclick=closeProduct;
document.getElementById("modalAdd").onclick=()=>addToCart(selectedProduct.id,document.getElementById("modalSize").value);

document.getElementById("checkout").onclick=()=>{
  if(!cart.length){toast("Your bag is empty");return}
  let total=0;
  const lines=cart.map((item,i)=>{const p=products.find(x=>x.id===item.id);total+=p.price*item.qty;return `${i+1}. ${p.name} | Size: ${item.size} | Qty: ${item.qty} | ${money(p.price*item.qty)}`});
  const message=`Hello BRAND BLVD! 👋\n\nI want to place an order:\n\n${lines.join("\n")}\n\nSubtotal: ${money(total)}\n\nPlease confirm availability and final order details.`;
  window.open(`https://wa.me/917986985911?text=${encodeURIComponent(message)}`,"_blank");
};

renderProducts();renderCart();updateCount();
