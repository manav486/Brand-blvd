# BRAND BLVD — Sangrur
Premium clothing-store demo website.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Go to Settings → Pages.
4. Choose Deploy from branch → `main` → `/root`.
5. Save and open the generated GitHub Pages URL.

## Customize
- Replace the placeholder product artwork with real product photos.
- Edit products/prices in `script.js`.
- Add the exact shop address and Google Maps link in `index.html`.
- The supplied BRAND BLVD logo is included as `logo.jpg`.

## Important
This is a front-end demo. It has a working cart, local storage and WhatsApp order handoff. A production Amazon/Flipkart-level system needs a backend/database, customer accounts, inventory, order management, payment gateway, shipping integration and security.
